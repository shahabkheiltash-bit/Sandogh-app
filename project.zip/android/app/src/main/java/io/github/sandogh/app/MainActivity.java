package io.github.sandogh.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
